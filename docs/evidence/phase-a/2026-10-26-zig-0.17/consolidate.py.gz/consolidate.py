import hashlib
import json
from pathlib import Path
import subprocess

rows = json.loads(Path('/tmp/zbeam-017-rollout/rollout-audit.json').read_text())['rows']
records = []
added = 0
variants = set()
for row in rows:
    ref = row['snapshot_tip']
    paths = subprocess.check_output(['/usr/bin/git', 'ls-tree', '-r', '--name-only', ref, '--', 'docs/evidence/phase-a'], text=True).splitlines()
    for name in paths:
        if not name.startswith('docs/evidence/phase-a/2026-10-25-zig-0.17'):
            continue
        blob = subprocess.check_output(['/usr/bin/git', 'show', ref + ':' + name])
        path = Path(name)
        if path.exists() and path.read_bytes() != blob:
            suffix = row['migration'].removeprefix('migrate/zig-0.17-')
            path = Path('docs/evidence/phase-a/2026-10-25-zig-0.17/branch-record-variants') / suffix / Path(name).name
            variants.add(str(path))
        if path.exists():
            assert path.read_bytes() == blob, (ref, name, path)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(blob)
            added += 1
        records.append({'ref': ref, 'source_path': name, 'stored_path': str(path), 'sha256': hashlib.sha256(blob).hexdigest()})
Path('/tmp/zbeam-017-rollout/consolidation-manifest.json').write_text(json.dumps(records, indent=2) + '\n')
print(f'PASS {len({r["stored_path"] for r in records})} distinct preserved paths; {added} newly copied in this retry; {len(variants)} differing inherited record versions retained separately')
