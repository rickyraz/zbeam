import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import subprocess
import yaml

root = Path('/home/rickyraz/projects/objective/zbeam-research/zig-0.17/master')
pairs = [
    ('master', 'master'),
    ('explore/lab-contracts', 'lab-contracts'),
    ('docs/worker-lifecycle-plan', 'docs-plan'),
    ('feat/worker-lifecycle', 'worker-lifecycle'),
    ('feat/monitorable-worker', 'monitorable-worker'),
    ('explore/zigler-baseline', 'zigler-baseline'),
    ('explore/batched-requests', 'batched-requests'),
    ('explore/beam-backpressure', 'beam-backpressure'),
    ('explore/io-overhead', 'io-overhead'),
    ('explore/worker-recovery', 'worker-recovery'),
    ('explore/actor-admission', 'actor-admission'),
    ('explore/allocator-baselines', 'allocator-baselines'),
    ('explore/request-arena', 'request-arena'),
    ('explore/snmalloc', 'snmalloc'),
]

def git(*args):
    return subprocess.check_output(['/usr/bin/git', *args], cwd=root, text=True).strip()

remote = dict(line.split()[::-1] for line in git('ls-remote', '--heads', 'origin').splitlines())
remote_tags = dict(line.split()[::-1] for line in git('ls-remote', '--tags', 'origin').splitlines())
source_names = {key.removeprefix('refs/heads/') for key in remote if not key.startswith('refs/heads/migrate/zig-0.17-')}
assert source_names == {source for source, _ in pairs}, source_names
rows = []
for source, suffix in pairs:
    migration = 'migrate/zig-0.17-' + suffix
    archive = 'archive/zig-0.16/' + source
    old = git('rev-parse', archive + '^{}')
    new = git('rev-parse', migration)
    assert git('cat-file', '-t', 'refs/tags/' + archive) == 'tag'
    assert remote_tags['refs/tags/' + archive] == git('rev-parse', archive)
    assert remote_tags['refs/tags/' + archive + '^{}'] == old
    assert remote['refs/heads/' + source] == old, source
    assert remote['refs/heads/' + migration] == new, migration
    subprocess.run(['/usr/bin/git', 'merge-base', '--is-ancestor', old, new], cwd=root, check=True)
    subprocess.run(['/usr/bin/git', 'diff', '--exit-code', old, new, '--', 'src', 'docs/adr'], cwd=root, check=True)
    assert '.minimum_zig_version = "0.17.0"' in git('show', migration + ':build.zig.zon')
    assert 'b.args' not in git('show', migration + ':build.zig')
    workflow = yaml.safe_load(git('show', migration + ':.github/workflows/ci.yml'))
    pins = [step['with']['version'] for job in workflow['jobs'].values() for step in job['steps'] if step.get('uses', '').startswith('mlugg/setup-zig@')]
    assert pins and set(pins) == {'0.17.0'}, (source, pins)
    readme = git('show', migration + ':benchmarks/README.md')
    assert '-Doptimize=ReleaseSafe' not in readme, source
    assert 'bench-port-vs-zbeam -Doptimize=safe -- 500' not in readme, source
    active = subprocess.run(['/usr/bin/git', 'grep', '-n', 'Doptimize=ReleaseSafe', migration, '--', ':!docs/evidence/**', ':!specs/**', ':!docs-id/**'], cwd=root, capture_output=True, text=True)
    assert active.returncode == 1, (source, active.stdout, active.stderr)
    rows.append({'source': source, 'archive': archive, 'old': old, 'migration': migration, 'snapshot_tip': new})

originals = []
for block in git('worktree', 'list', '--porcelain').split('\n\n'):
    fields = dict(line.split(' ', 1) for line in block.splitlines() if ' ' in line)
    path = fields['worktree']
    if Path(path) == root:
        continue
    branch = fields['branch'].removeprefix('refs/heads/')
    assert fields['HEAD'] == git('rev-parse', 'archive/zig-0.16/' + branch + '^{}')
    assert subprocess.check_output(['/usr/bin/git', '-C', path, 'status', '--porcelain=v1', '--untracked-files=all'], text=True) == '', path
    originals.append({'path': path, 'branch': branch, 'head': fields['HEAD'], 'clean': True})
assert len(originals) == 9, originals
compilers = {}
for version, path, expected in [
    ('0.16.0', '/home/rickyraz/.vscode-server/data/User/globalStorage/ziglang.vscode-zig/zig/x86_64-linux-0.16.0/zig', '2317bbb91798556d9d0f38aabdac23db83f0979b25f767259ae474546724087c'),
    ('0.17.0', '/home/rickyraz/.local/share/mise/installs/zig/0.17.0/zig', '7c61539af19fa4082c94848f1c2b57b89e76dc6cfd5bd4c57764c3caf8f82272'),
]:
    with open(path, 'rb') as binary:
        digest = hashlib.file_digest(binary, 'sha256').hexdigest()
    assert digest == expected, path
    assert subprocess.check_output([path, 'version'], text=True).strip() == version
    compilers[version] = {'path': path, 'sha256': digest}
print(json.dumps({'snapshot_utc': datetime.now(timezone.utc).isoformat(), 'rows': rows, 'original_worktrees': originals, 'compilers': compilers, 'result': 'PASS 14/14 source/candidate refs and published archives, source/ADR identity, current command/toolchain metadata and 9 clean original worktrees'}, indent=2))
